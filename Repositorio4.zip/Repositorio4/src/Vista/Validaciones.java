
package Vista;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validaciones {
    public boolean validar_cedula(String cedula){
      return  cedula.matches("[0-9]{10}");
            
        
    }
    public boolean validarUsuario(String usuario){
        int longitud=0;
        longitud=usuario.length();
        if ((longitud>=8)&&(longitud<=10)) {
            return true;
        }else{
            return false;
        }
    }
    
    
    public boolean validarcontraseña(String contraseña){
       String almenosunaletramayus=".[A-Z].";
       String almenosunaletramin=".[a-z].";
       String almenosunnumero=".[0-9].";
        if (contraseña.matches(almenosunaletramayus)&&contraseña.matches(almenosunaletramin)&&contraseña.matches(almenosunnumero)); {
         int longitud=0;
         longitud=contraseña.length();
         if (longitud>=8&&longitud<=12) {
            return true;
        }else
                 
         return false;
        }
    }
    public boolean valida_repeticion_clave(String clave,String repetir_clave){
        if (repetir_clave.compareTo(clave)==0) {
            return true;
        }else{
            return false;
        }
    }
    public boolean validarsolotexto(String texto){
        return texto.matches("[a-zA-Z]*");
    }
//    public boolean validarcorreo(String correo){
//        Pattern pattern=Pattern.compile("^[_A-Za-z0-9-\\\\+]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})$");
//        Matcher mather=pattern.matcher(correo);
//        return mather.find();
//    
    
    public boolean validarcorreo(String correo){
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher mather = pattern.matcher(correo);
        return mather.find();
    }
}
