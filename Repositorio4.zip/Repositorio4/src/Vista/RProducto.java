
package Vista;

import Modelo.Producto;
import static Vista.RCliente.txtcorreo;
import static Vista.RCliente.txtdireccion;
import java.awt.Color;
import java.awt.Font;
import java.util.List;
import javax.swing.JOptionPane;

public class RProducto extends javax.swing.JFrame {

    Producto producto =new Producto();

    public RProducto() {
        initComponents();
        this.setLocationRelativeTo(null);
        actualizatabla();
        tblcliente.getTableHeader().setFont(new Font("Microsoft YaHei",1,13));
        tblcliente.getTableHeader().setOpaque(false);
        tblcliente.getTableHeader().setBackground(new Color(0,147,185));
        tblcliente.getTableHeader().setForeground(new Color(255,255,255));
        tblcliente.setRowHeight(25);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        lblcodigo = new javax.swing.JLabel();
        lblnombre = new javax.swing.JLabel();
        lblprecio = new javax.swing.JLabel();
        lblmarca = new javax.swing.JLabel();
        txtcodigo = new javax.swing.JTextField();
        txtnombre = new javax.swing.JTextField();
        txtprecio = new javax.swing.JTextField();
        txtmarca = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        lblsalir = new javax.swing.JLabel();
        pnlbuscar = new javax.swing.JPanel();
        lblbuscar4 = new javax.swing.JLabel();
        pnlregistrar = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        pnlmodificar = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        pnleliminar = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblcliente = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        lblcodigo.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        lblcodigo.setText("Código:");

        lblnombre.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        lblnombre.setText("Nombre:");

        lblprecio.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        lblprecio.setText("Precio:");

        lblmarca.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        lblmarca.setText("Marca:");

        txtcodigo.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        txtcodigo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcodigoFocusLost(evt);
            }
        });
        txtcodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodigoActionPerformed(evt);
            }
        });

        txtnombre.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        txtnombre.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtnombreFocusLost(evt);
            }
        });

        txtprecio.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        txtprecio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtprecioFocusLost(evt);
            }
        });
        txtprecio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtprecioActionPerformed(evt);
            }
        });

        txtmarca.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        txtmarca.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtmarcaFocusLost(evt);
            }
        });

        jPanel4.setBackground(new java.awt.Color(0, 147, 185));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("REGISTRAR PRODUCTO");

        lblsalir.setFont(new java.awt.Font("Yu Gothic UI Semilight", 0, 24)); // NOI18N
        lblsalir.setForeground(new java.awt.Color(255, 255, 255));
        lblsalir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblsalir.setText("X");
        lblsalir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        lblsalir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblsalirMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(117, 117, 117)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                .addComponent(lblsalir, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(lblsalir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pnlbuscar.setBackground(new java.awt.Color(255, 255, 255));
        pnlbuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pnlbuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlbuscarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnlbuscarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pnlbuscarMouseExited(evt);
            }
        });

        lblbuscar4.setFont(new java.awt.Font("Yu Gothic UI Semilight", 1, 14)); // NOI18N
        lblbuscar4.setForeground(new java.awt.Color(102, 102, 102));
        lblbuscar4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblbuscar4.setText("Buscar");
        lblbuscar4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblbuscar4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblbuscar4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblbuscar4MouseExited(evt);
            }
        });

        javax.swing.GroupLayout pnlbuscarLayout = new javax.swing.GroupLayout(pnlbuscar);
        pnlbuscar.setLayout(pnlbuscarLayout);
        pnlbuscarLayout.setHorizontalGroup(
            pnlbuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlbuscarLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblbuscar4, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnlbuscarLayout.setVerticalGroup(
            pnlbuscarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblbuscar4, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
        );

        pnlregistrar.setBackground(new java.awt.Color(0, 147, 185));
        pnlregistrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pnlregistrar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlregistrarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnlregistrarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pnlregistrarMouseExited(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("  Registrar");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlregistrarLayout = new javax.swing.GroupLayout(pnlregistrar);
        pnlregistrar.setLayout(pnlregistrarLayout);
        pnlregistrarLayout.setHorizontalGroup(
            pnlregistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlregistrarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE))
        );
        pnlregistrarLayout.setVerticalGroup(
            pnlregistrarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
        );

        pnlmodificar.setBackground(new java.awt.Color(0, 147, 185));
        pnlmodificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pnlmodificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnlmodificarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnlmodificarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pnlmodificarMouseExited(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("  Modificar");
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnlmodificarLayout = new javax.swing.GroupLayout(pnlmodificar);
        pnlmodificar.setLayout(pnlmodificarLayout);
        pnlmodificarLayout.setHorizontalGroup(
            pnlmodificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlmodificarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
        );
        pnlmodificarLayout.setVerticalGroup(
            pnlmodificarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
        );

        pnleliminar.setBackground(new java.awt.Color(0, 147, 185));
        pnleliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        pnleliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pnleliminarMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                pnleliminarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                pnleliminarMouseExited(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("    Eliminar");
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pnleliminarLayout = new javax.swing.GroupLayout(pnleliminar);
        pnleliminar.setLayout(pnleliminarLayout);
        pnleliminarLayout.setHorizontalGroup(
            pnleliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnleliminarLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE))
        );
        pnleliminarLayout.setVerticalGroup(
            pnleliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)
        );

        tblcliente.setFont(new java.awt.Font("Microsoft YaHei", 0, 13)); // NOI18N
        tblcliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Codigo", "Nombre", "Precio"
            }
        ));
        tblcliente.setIntercellSpacing(new java.awt.Dimension(0, 0));
        tblcliente.setRowHeight(25);
        tblcliente.setSelectionBackground(new java.awt.Color(255, 51, 51));
        tblcliente.setShowVerticalLines(false);
        tblcliente.getTableHeader().setReorderingAllowed(false);
        tblcliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblclienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblcliente);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 481, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(pnlregistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(36, 36, 36)
                                .addComponent(pnlmodificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(pnleliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblnombre)
                                    .addComponent(lblcodigo)
                                    .addComponent(lblprecio)
                                    .addComponent(lblmarca))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(txtcodigo)
                                            .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(pnlbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtmarca, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator1))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtcodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblcodigo))
                    .addComponent(pnlbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblnombre))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtprecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblprecio))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmarca)
                    .addComponent(txtmarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pnlregistrar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlmodificar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnleliminar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtcodigoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcodigoFocusLost
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtcodigoFocusLost

    private void txtcodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcodigoActionPerformed

    private void txtnombreFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtnombreFocusLost
        // TODO add your handling code here:
        Validaciones validar =new Validaciones();
        boolean resultado=validar.validarsolotexto(txtnombre.getText());
        if (resultado==false) {
            JOptionPane.showMessageDialog(null, "No puede ingresar numeros en este campo");
            txtnombre.setText("");
        }
    }//GEN-LAST:event_txtnombreFocusLost

    private void txtprecioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtprecioFocusLost
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txtprecioFocusLost

    private void txtmarcaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtmarcaFocusLost
        // TODO add your handling code here:
        Validaciones validar =new Validaciones();
        boolean resultado=validar.validarsolotexto(txtmarca.getText());
        if (resultado==false) {
            JOptionPane.showMessageDialog(null, "No puede ingresar numeros en este campo");
            txtmarca.setText("");
        }
    }//GEN-LAST:event_txtmarcaFocusLost

    private void tblclienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblclienteMouseClicked
        // TODO add your handling code here:
        int seleccionado = tblcliente.getSelectedRow();
        limpiarDatos();

    }//GEN-LAST:event_tblclienteMouseClicked

    private void txtprecioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtprecioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtprecioActionPerformed

    private void lblsalirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsalirMouseClicked
        // TODO add your handling code here:
        VGerente VGeren=new VGerente();
        this.dispose();
        VGeren.setVisible(true);
    }//GEN-LAST:event_lblsalirMouseClicked

    private void lblbuscar4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbuscar4MouseClicked
        // TODO add your handling code here:
        if (txtcodigo.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el codigo para realizar la busqueda");
        }
        else
        {
            List<Producto>lista= producto.busqueda_producto(txtcodigo.getText());
            for (int i = 0; i < lista.size(); i++) {
                if (lista.get(i).getPro_codigo().equals(txtcodigo.getText())) {
                    txtcodigo.setText(lista.get(i).getPro_codigo());
                    txtnombre.setText(lista.get(i).getPro_nombre());
                    txtprecio.setText(lista.get(i).getPro_precio().toString());
                    txtmarca.setText(lista.get(i).getPro_marca());
                    mostrar_busqueda();
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "El producto no existe");
                }
            }
        }
    }//GEN-LAST:event_lblbuscar4MouseClicked

    private void lblbuscar4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbuscar4MouseEntered
        // TODO add your handling code here:
        lblbuscar4.setBackground(new Color(241,242,243));
    }//GEN-LAST:event_lblbuscar4MouseEntered

    private void lblbuscar4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbuscar4MouseExited
        // TODO add your handling code here:
        pnlbuscar.setBackground(Color.white);
    }//GEN-LAST:event_lblbuscar4MouseExited

    private void pnlbuscarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlbuscarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_pnlbuscarMouseClicked

    private void pnlbuscarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlbuscarMouseEntered
        // TODO add your handling code here:
        //DDE0E3
        pnlbuscar.setBackground(new Color(241,242,243));
    }//GEN-LAST:event_pnlbuscarMouseEntered

    private void pnlbuscarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlbuscarMouseExited
        // TODO add your handling code here:
        pnlbuscar.setBackground(Color.white);
    }//GEN-LAST:event_pnlbuscarMouseExited

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:
        if (txtcodigo.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Debe ingresar el codigo del producto a eliminar");
        }
        else
        {
            producto.eliminar_producto(txtcodigo.getText());
            actualizatabla();
        }

    }//GEN-LAST:event_jLabel13MouseClicked

    private void pnleliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnleliminarMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_pnleliminarMouseClicked

    private void pnleliminarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnleliminarMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_pnleliminarMouseEntered

    private void pnleliminarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnleliminarMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_pnleliminarMouseExited

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
       if (txtnombre.getText().equals("") || txtprecio.getText().equals("") ||  txtcodigo.getText().equals("") || txtdireccion.getText().equals("") || txtmarca.getText().equals("") || txtcorreo.getText().equals("")) {
            JOptionPane.showMessageDialog(null, "Debe realizar una consulta antes de modificar un cliente");
        }
        else
        {
            double precio = Double.parseDouble(txtprecio.getText());
            producto.insertar_producto(txtcodigo.getText(), txtnombre.getText(), precio, txtmarca.getText());
            actualizatabla();
            limpiarDatos();
        }
    }//GEN-LAST:event_jLabel11MouseClicked

    private void pnlmodificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlmodificarMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_pnlmodificarMouseClicked

    private void pnlmodificarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlmodificarMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_pnlmodificarMouseEntered

    private void pnlmodificarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlmodificarMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_pnlmodificarMouseExited

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        if( txtcodigo.getText().equals("") || txtnombre.getText().equals("") || txtprecio.getText().equals("") || txtmarca.getText().equals("")){
            JOptionPane.showMessageDialog(null, "HAY CAMPOS VACIOS");
        }else
            
        {
            double precio = Double.parseDouble(txtprecio.getText());
            producto.insertar_producto(txtcodigo.getText(), txtnombre.getText(), precio, txtmarca.getText());
            actualizatabla();
            limpiarDatos();
        }
    }//GEN-LAST:event_jLabel10MouseClicked

    private void pnlregistrarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlregistrarMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_pnlregistrarMouseClicked

    private void pnlregistrarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlregistrarMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_pnlregistrarMouseEntered

    private void pnlregistrarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pnlregistrarMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_pnlregistrarMouseExited

    public void mostrar_busqueda(){
        
        List <Producto> lista=producto.busqueda_producto(txtcodigo.getText());
         
        String matriz [][] = new String [lista.size()][3];
        
        for (int i=0; i<lista.size(); i++){
            matriz[i][0] = lista.get(i).getPro_codigo();
            matriz[i][1] =lista.get(i).getPro_nombre();
            matriz[i][2] = lista.get(i).getPro_precio().toString();
        }
        
        tblcliente.setModel(new javax.swing.table.DefaultTableModel(
            matriz,
            new String [] {
                "CODIGO", "NOMBRE", "PRECIO"
            }
        ));
    }
    public void actualizatabla(){
       
        List<Producto>lista=producto.mostrarDatos_producto();
                   
        String matriz [][] = new String [lista.size()][3];
        
        for (int i=0; i<lista.size(); i++){
            matriz[i][0] = lista.get(i).getPro_codigo();
            matriz[i][1] =lista.get(i).getPro_nombre();
            matriz[i][2] = lista.get(i).getPro_precio().toString();
        }
        
        tblcliente.setModel(new javax.swing.table.DefaultTableModel(
            matriz,
            new String [] {
                "CODIGO", "NOMBRE", "PRECIO"
            }
        ));
    }
    
     public void mostrarResultadoBusqueda(String dato){
        Producto producto = new Producto();
        List<Producto> lista = producto.buscarCodigo(dato);
        txtcodigo.setText(lista.get(0).getPro_codigo());
        txtnombre.setText(lista.get(0).getPro_nombre());
        txtprecio.setText(lista.get(0).getPro_precio().toString());
        txtmarca.setText(lista.get(0).getPro_marca());
        
        
    }
        
    public void limpiarDatos(){
        
        txtcodigo.setText("");
        txtnombre.setText("");
        txtprecio.setText("");
        txtmarca.setText("");
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RProducto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RProducto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblbuscar4;
    private javax.swing.JLabel lblcodigo;
    private javax.swing.JLabel lblmarca;
    private javax.swing.JLabel lblnombre;
    private javax.swing.JLabel lblprecio;
    private javax.swing.JLabel lblsalir;
    private javax.swing.JPanel pnlbuscar;
    private javax.swing.JPanel pnleliminar;
    private javax.swing.JPanel pnlmodificar;
    private javax.swing.JPanel pnlregistrar;
    private javax.swing.JTable tblcliente;
    public static javax.swing.JTextField txtcodigo;
    public static javax.swing.JTextField txtmarca;
    public static javax.swing.JTextField txtnombre;
    public static javax.swing.JTextField txtprecio;
    // End of variables declaration//GEN-END:variables
}
