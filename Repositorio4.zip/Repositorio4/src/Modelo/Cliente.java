/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import SQL.conexionsql;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author tefip
 */
public class Cliente {
   private String cedula, nombre,apellido, telefono, direccion, correo;
conexionsql con=new conexionsql();
    public Cliente(String cedula, String nombre, String apellido, String telefono, String direccion, String correo) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.direccion = direccion;
        this.correo = correo;
    }

    public Cliente() {
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }
    
    java.sql.Statement st;
ResultSet rs;
    
     public void insertar_cliente(String cedula, String nombre, String apellido, String telefono, String direccion, String correo) {
        try {
            Connection conexion = con.conexionsql();
            st = conexion.createStatement();
            String sql = "insert into clientes(cedula,nombre,apellido, telefono, direccion, correo) values('" + cedula + "','" + nombre + "','" + apellido + "','" + telefono + "','" + direccion + "','" + correo+"');";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "EL REGISTRO SE GUARDO CORRECTAMENTE", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "UPS! Algo sucedio y no se guardo el registro", "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
     public List<Cliente> mostrarDatos_clientes(){
     try{   
         ArrayList<Cliente>lista=new ArrayList<Cliente>();
         Connection conexion=con.conexionsql();
         st=conexion.createStatement();
         String sql= "SELECT * FROM clientes";
          rs= st.executeQuery(sql);
          
         while(rs.next()){
             //
             
             Cliente cliente=new Cliente();
             
             
             
             cliente.setCedula(rs.getString("cedula"));
             cliente.setNombre(rs.getString("nombre"));
             cliente.setApellido(rs.getString("apellido"));
             cliente.setTelefono(rs.getString("telefono"));
             cliente.setDireccion(rs.getString("direccion"));
             cliente.setCorreo(rs.getString("correo"));
             
             
             
             
             
             lista.add(cliente);
                }
             st.close();
            conexion.close();
       return lista;
     }catch(SQLException ex){
         Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE,null,ex);
         return null;
     }
    }
    public void eliminar_cliente(String cedula){
       try{
       Connection conexion=con.conexionsql();
         st=conexion.createStatement();
         String sql="delete from clientes where cedula='"+cedula+"';";
         st.execute(sql);
         st.close();
         conexion.close();
           JOptionPane.showMessageDialog(null, "Registro eliminado correctamente", "ELIMINADO ", JOptionPane.INFORMATION_MESSAGE); 
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, "No se ha encontrado usuario a eliminar", "Error ", JOptionPane.ERROR_MESSAGE); 
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "No se ha encontrado usuario a eliminar ...", "Error ", JOptionPane.ERROR_MESSAGE); 
       }
   }
    
    public List<Cliente> busqueda_cliente(String cedula){
        try{
           Connection conexion=con.conexionsql();
            ArrayList<Cliente>lista=new ArrayList<Cliente>();
         st=conexion.createStatement();
         String sql="select * from clientes where cedula='"+cedula+"';";
       rs= st.executeQuery(sql);
       while(rs.next()){
           Cliente cliente=new Cliente();
             
             
            
             cliente.setCedula(rs.getString("cedula"));
             cliente.setNombre(rs.getString("nombre"));
             cliente.setApellido(rs.getString("apellido"));
             cliente.setTelefono(rs.getString("telefono"));
             cliente.setDireccion(rs.getString("direccion"));
             cliente.setCorreo(rs.getString("correo"));
             
             
             lista.add(cliente);
       }
       st.close();
       conexion.close();
       return lista;
       
       }catch(SQLException ex){
         Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE,null,ex);
         return null;
     }
           
   }
     public void actualizar_cliente(String cedula, String nombre, String apellido, String telefono, String direccion, String correo){
       try{
           Connection conexion=con.conexionsql();
         st=conexion.createStatement();
         String sql="update clientes set apellido='"+apellido+"',telefono='"+telefono+"',direccion='"+direccion+"',correo='"+correo+"',nombre='"+nombre+"' where cedula='"+cedula+"';";
       st.executeUpdate(sql);
       st.close();
       conexion.close();
       JOptionPane.showMessageDialog(null, "El registro se actualizo", "exito ", JOptionPane.INFORMATION_MESSAGE);
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "No se pudo actualizar", "Error ", JOptionPane.ERROR_MESSAGE);
       }
   }
    
    
    public List<Cliente> buscarCedula(String criterio){
        try{
            Connection conexion=con.conexionsql();
            ArrayList<Cliente> lista = new ArrayList<Cliente>();
             conexionsql conecta= new conexionsql();
            String sql = "SELECT * FROM clientes WHERE cedula = '" + criterio + "';";
            
            ResultSet rs  = conecta.query(sql);
            while(rs.next()){
                Cliente persona  = new Cliente();
                persona.setCedula(rs.getString("cedula"));
                persona.setNombre(rs.getString("nombres"));
                persona.setApellido(rs.getString("apellidos"));
                persona.setTelefono(rs.getString("telefono"));
                persona.setDireccion(rs.getString("direccion"));
                persona.setCorreo(rs.getString("correo"));
                lista.add(persona);
              
            }
        rs.close();
        return lista;
        }catch(SQLException ex){
           Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
           return null;
        }
    } 
    
     public List<Cliente> buscar(String criterio){
        try{
            Connection conexion=con.conexionsql();
            ArrayList<Cliente> lista = new ArrayList<Cliente>();
            conexionsql conecta= new conexionsql();
            String sql = "SELECT * FROM clientes WHERE UPPER (nombre) like UPPER('%"+ criterio +"%') or UPPER (apellido) like UPPER('%"+ criterio +"%')";
            ResultSet rs  = conecta.query(sql);
            while(rs.next()){
                Cliente persona  = new Cliente();
                persona.setCedula(rs.getString("cedula"));
                persona.setNombre(rs.getString("nombres"));
                persona.setApellido(rs.getString("apellidos"));
                persona.setTelefono(rs.getString("telefono"));
                persona.setDireccion(rs.getString("direccion"));
                persona.setCorreo(rs.getString("correo"));
                lista.add(persona);
              
            }
        rs.close();
            return lista;
        }catch(SQLException ex){
           Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
           return null;
        }
    } 
     
      public List<Cliente> buscar_por_nombre(String nombre){
        try{
            Connection conexion=con.conexionsql();
            ArrayList<Cliente> lista = new ArrayList<Cliente>();
             conexionsql conecta= new conexionsql();
            String sql = "select * from clientes where nombre='" + nombre + "';";
            
            ResultSet rs  = conecta.query(sql);
            while(rs.next()){
                Cliente persona  = new Cliente();
                persona.setCedula(rs.getString("cedula"));
                persona.setNombre(rs.getString("nombres"));
                persona.setApellido(rs.getString("apellidos"));
                persona.setTelefono(rs.getString("telefono"));
                persona.setDireccion(rs.getString("direccion"));
                persona.setCorreo(rs.getString("correo"));
                lista.add(persona);
              
            }
        rs.close();
        return lista;
        }catch(SQLException ex){
           Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
           return null;
        }
    }  
    
     
     
     
}
