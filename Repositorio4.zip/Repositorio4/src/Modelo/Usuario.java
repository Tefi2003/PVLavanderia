/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Modelo.Cliente;
import Modelo.Usuario;
import SQL.conexionsql;

import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DELL
 */
public class Usuario {
    private  String cedula, nombre,apellido, telefono, direccion, correo ,usuario, rol, clave;

conexionsql con=new conexionsql();
    public Usuario() {
    }

    public Usuario(String cedula, String nombre, String apellido, String telefono, String direccion, String correo, String usuario, String rol, String clave) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.direccion = direccion;
        this.correo = correo;
        this.usuario = usuario;
        this.rol = rol;
        this.clave = clave;
    }

    

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

  

  java.sql.Statement st;
ResultSet rs;
public void insertar_usuario(String cedula, String nombre, String apellido, String telefono, String direccion, String correo, String usuario, String rol, String clave) {
        try {
            
            Connection conexion = con.conexionsql();
             st=conexion.createStatement();
            
            String sql = "insert into usuarios(cedula,nombre,apellido,telefono,direccion,correo,usuario,rol,clave) values('" + cedula + "','" + nombre + "','" + apellido + "','" + telefono + "','" + direccion + "','" + correo + "','" + usuario + "','" + rol + "','" + clave + "');";

            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "EL REGISTRO SE GUARDO CORRECTAMENTE", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "UPS! Algo sucedio y no se guardo el registro", "Mensaje", JOptionPane.ERROR_MESSAGE);
        }
    }
   public List<Usuario> ingreso_login(String usuario,String clave) {
        try{
            Usuario user=new Usuario();
            Connection conexion=con.conexionsql();
            st=conexion.createStatement();
            String sql="select * from usuarios where usuario='"+usuario+"'and clave='"+clave+"';";
            rs=st.executeQuery(sql);
             ArrayList<Usuario>lista=new ArrayList<Usuario>();
            if (rs.next()) {
               
                user.setCedula(rs.getString("cedula"));
                user.setNombre(rs.getString("nombre"));
                user.setApellido(rs.getString("apellido"));
                user.setTelefono(rs.getString("telefono"));
                user.setDireccion(rs.getString("direccion"));
                user.setCorreo(rs.getString("correo"));
                user.setUsuario(rs.getString("usuario"));
                user.setRol(rs.getString("rol"));
                user.setClave(rs.getString("clave"));
                lista.add(user);
            }else{
                
              JOptionPane.showMessageDialog(null, "no se encontro registro", "Mensaje", JOptionPane.INFORMATION_MESSAGE);  
            
              }
            st.close();
            conexion.close();
            
            return lista;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "no hay registros", "Error ", JOptionPane.INFORMATION_MESSAGE);  
            return null;
        }
        
    }

   public List<Usuario> mostrarDatos_usuario(){
     try{   
         ArrayList<Usuario>lista=new ArrayList<Usuario>();
         Connection conexion=con.conexionsql();
         st=conexion.createStatement();
         String sql= "SELECT * FROM usuarios";
          rs= st.executeQuery(sql);
          
         while(rs.next()){
             //
             
             Usuario usuario=new Usuario();
             
             
             usuario.setUsuario(rs.getString("usuario"));
             usuario.setCedula(rs.getString("cedula"));
             usuario.setNombre(rs.getString("nombre"));
             usuario.setApellido(rs.getString("apellido"));
             usuario.setTelefono(rs.getString("telefono"));
             usuario.setDireccion(rs.getString("direccion"));
             usuario.setCorreo(rs.getString("correo"));
             
             usuario.setRol(rs.getString("rol"));
             usuario.setClave(rs.getString("clave"));
             
             
             lista.add(usuario);
                }
             st.close();
            conexion.close();
       return lista;
     }catch(SQLException ex){
         Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE,null,ex);
         return null;
     }
    }
    
   public void eliminar_usuario(String cedula){
       try{
       Connection conexion=con.conexionsql();
         st=conexion.createStatement();
         String sql="delete from usuarios where cedula='"+cedula+"';";
         st.execute(sql);
         st.close();
         conexion.close();
           JOptionPane.showMessageDialog(null, "Registro eliminado correctamente", "ELIMINADO ", JOptionPane.INFORMATION_MESSAGE); 
       }catch(SQLException e){
           JOptionPane.showMessageDialog(null, "No se ha encontrado usuario a eliminar", "Error ", JOptionPane.ERROR_MESSAGE); 
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "No se ha encontrado usuario a eliminar ...", "Error ", JOptionPane.ERROR_MESSAGE); 
       }
   }
   public void actualizar_usuario(String cedula, String nombre, String apellido, String telefono, String direccion, String correo, String usuario, String rol, String clave){
       try{
           Connection conexion=con.conexionsql();
         st=conexion.createStatement();
         String sql="update usuarios set apellido='"+apellido+"',telefono='"+telefono+"',direccion='"+direccion+"',correo='"+correo+"',usuario='"+usuario+"',rol='"+rol+"',clave='"+clave+"',nombre='"+nombre+"' where cedula='"+cedula+"';";
       st.executeUpdate(sql);
       st.close();
       conexion.close();
       JOptionPane.showMessageDialog(null, "El registro se actualizo", "exito ", JOptionPane.INFORMATION_MESSAGE);
       }catch(Exception e){
           JOptionPane.showMessageDialog(null, "No se pudo actualizar", "Error ", JOptionPane.ERROR_MESSAGE);
       }
   }
   public List<Usuario> busqueda_usuario(String cedula){
        try{
           Connection conexion=con.conexionsql();
            ArrayList<Usuario>lista=new ArrayList<Usuario>();
         st=conexion.createStatement();
         String sql="select * from usuarios where cedula='"+cedula+"';";
       rs= st.executeQuery(sql);
       while(rs.next()){
           Usuario usuario=new Usuario();
             
             
             usuario.setUsuario(rs.getString("usuario"));
             usuario.setCedula(rs.getString("cedula"));
             usuario.setNombre(rs.getString("nombre"));
             usuario.setApellido(rs.getString("apellido"));
             usuario.setTelefono(rs.getString("telefono"));
             usuario.setDireccion(rs.getString("direccion"));
             usuario.setCorreo(rs.getString("correo"));
             
             usuario.setRol(rs.getString("rol"));
             usuario.setClave(rs.getString("clave"));
             lista.add(usuario);
       }
       st.close();
       conexion.close();
       return lista;
       
       }catch(SQLException ex){
         Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE,null,ex);
         return null;
     }
   }
}

