
package SQL;
import Modelo.Orden;
import Modelo.Producto;
import SQL.conexionsql;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class sql {
    //conexionsql con=new conexionsql();
    conexionsql con=new conexionsql();

    public int id_incrementable()
    {
        int id=1;
        java.sql.Statement st;
        ResultSet rs;
        try
        {
            Connection conexion=con.conexionsql();
            st=conexion.createStatement();
            String sql= "select max (num_orden) from ordenes";
            rs= st.executeQuery(sql);
            while(rs.next())
            {
                id=rs.getInt(1)+1;
            }
        st.close();
        conexion.close();
        }
        catch(Exception ex)
        {
            Logger.getLogger(sql.class.getName()).log(Level.SEVERE,null,ex);
        }
        return id;
    }
    
}
